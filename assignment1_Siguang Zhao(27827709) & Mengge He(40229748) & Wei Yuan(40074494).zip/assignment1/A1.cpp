/* 
=========================================================
   3D Basketball Scene - Overview
   -------------------------------
   Features:
   - Textured bouncing sphere (basketball) with gravity
   - Floor plane with texture and dynamic lighting
   - Shadow rendering using alpha blending
   - Interactive FPS-style camera (WASD + mouse)
   - Real-time shader lighting model with point lights
=========================================================
*/

// main.cpp
#define STB_IMAGE_IMPLEMENTATION
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "stb/stb_image.h"

#include <vector>
#include <iostream>

// Camera position and orientation parameters
glm::vec3 cameraPos = glm::vec3(0.0f, 1.5f, 5.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

// Mouse control for camera
float yaw = -90.0f; // Yaw initialized to face down -Z axis by default
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0f / 2.0;
bool firstMouse = true;

// Field of view for perspective projection
float fov = 45.0f;

// Time tracking for frame-based movement
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// Screen size
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// Callback and input handler function declarations
void framebuffer_size_callback(GLFWwindow *window, int width, int height);
void mouse_callback(GLFWwindow *window, double xpos, double ypos);
void scroll_callback(GLFWwindow *window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);

// Loads an image file using stb_image and creates an OpenGL 2D texture
unsigned int loadTexture(const char *path);

// Generates a UV sphere with position, normal, and texture coordinates
void createSphere(std::vector<float> &vertices, std::vector<unsigned int> &indices,
                  unsigned int X_SEGMENTS = 64, unsigned int Y_SEGMENTS = 64);

// Physics parameters for the bouncing basketball
float ballPosY = 0.5f;         // Current vertical position of the ball
float ballVelocityY = 0.0f;    // Vertical velocity of the ball (positive = up)
const float gravity = -9.8f;   // Gravitational acceleration
const float damping = 0.7f;    // Velocity reduction factor after bouncing
const float ballRadius = 0.5f; // Radius of the basketball
bool isBouncing = true;        // Indicates whether the ball is currently bouncing

int main()
{
    // ---------------- Initialize GLFW & GLEW ----------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); // Request OpenGL version 3.3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); // Use core profile

    GLFWwindow *window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Basketball Scene", NULL, NULL);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    // Set input callbacks for resizing, mouse movement, and scrolling
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);

    // Disable mouse cursor and capture it for camera control
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    if (glewInit() != GLEW_OK)
    {
        std::cerr << "Failed to initialize GLEW\n";
        return -1;
    }
    glEnable(GL_DEPTH_TEST); // Enable depth testing for 3D rendering

    // ---------------- Shader source code ----------------
    const char *vertexShaderSource = R"(#version 330 core
    layout(location = 0) in vec3 aPos;
    layout(location = 1) in vec3 aNormal;
    layout(location = 2) in vec2 aTexCoords;

    out vec3 FragPos;
    out vec3 Normal;
    out vec2 TexCoords;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main(){
        FragPos = vec3(model * vec4(aPos, 1.0));
        Normal  = mat3(transpose(inverse(model))) * aNormal;
        TexCoords = aTexCoords;
        gl_Position = projection * view * vec4(FragPos, 1.0);
    })";

    const char *fragmentShaderSource = R"(#version 330 core
    struct PointLight {
        vec3 position;
        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };
    #define NR_POINT_LIGHTS 2

    in vec3 FragPos;
    in vec3 Normal;
    in vec2 TexCoords;

    out vec4 FragColor;

    uniform sampler2D texture_diffuse1;
    uniform vec3 viewPos;
    uniform PointLight pointLights[NR_POINT_LIGHTS];
    uniform float shininess;

    void main(){
        vec3 norm = normalize(Normal);
        vec3 viewDir = normalize(viewPos - FragPos);
        vec3 result = vec3(0.0);
        vec3 texColor = texture(texture_diffuse1, TexCoords).rgb;

        for(int i = 0; i < NR_POINT_LIGHTS; i++){
            // Ambient lighting: basic light level regardless of direction
            vec3 ambient = pointLights[i].ambient * texColor;

            // Diffuse lighting: depends on angle between light and surface normal
            vec3 lightDir = normalize(pointLights[i].position - FragPos);
            float diff = max(dot(norm, lightDir), 0.0);
            vec3 diffuse = pointLights[i].diffuse * diff * texColor;

            // Specular lighting: simulates shiny highlights
            vec3 reflectDir = reflect(-lightDir, norm);
            float spec = pow(max(dot(viewDir, reflectDir), 0.0), shininess);
            vec3 specular = pointLights[i].specular * spec;

            // Add all lighting components
            result += ambient + diffuse + specular;
        }
        FragColor = vec4(result, 1.0);
    })";

    //------------------------------------------------------------------------
    // Fragment shader for rendering shadows as semi-transparent dark shapes
    const char *shadowFragmentShaderSource = R"(#version 330 core
        out vec4 FragColor;
        void main(){
            FragColor = vec4(0.0, 0.0, 0.0, 0.3); // Render shadow with 30% opacity black
    })";
    //-------------------------------------------------------------------------

    // Shader compilation helper function (lambda)
    // Compiles a given shader type from source and returns the shader ID
    auto compileShader = [&](GLenum type, const char *src)
    {
        GLuint shader = glCreateShader(type);
        glShaderSource(shader, 1, &src, NULL);
        glCompileShader(shader);
        // TODO: Add shader compilation error checking here
        return shader;
    };

    // Compile vertex and fragment shaders, link them into a shader program
    GLuint vert = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    GLuint frag = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vert);
    glAttachShader(shaderProgram, frag);
    glLinkProgram(shaderProgram);
    // TODO: Add shader program linking error checking here

    // Shaders can be deleted after linking into the program
    glDeleteShader(vert);
    glDeleteShader(frag);
    //-------------------------------------------------------------------------
    // Compile and link shadow shader program (reuses vertex shader)
    GLuint shadowFrag = compileShader(GL_FRAGMENT_SHADER, shadowFragmentShaderSource);
    GLuint shadowShaderProgram = glCreateProgram();
    glAttachShader(shadowShaderProgram, vert);       // Reuse the main vertex shader
    glAttachShader(shadowShaderProgram, shadowFrag); // Attach the shadow fragment shader
    glLinkProgram(shadowShaderProgram);
    glDeleteShader(shadowFrag); // Safe to delete after linking
                                //-------------------------------------------------------------------------

    // ---------------- Generate sphere geometry ----------------
    // Create sphere vertex and index data (position, normals, texture coords)
    std::vector<float> sphereVertices;
    std::vector<unsigned int> sphereIndices;
    createSphere(sphereVertices, sphereIndices);

    // Generate and bind VAO, VBO, and EBO for the sphere
    unsigned int sphereVAO, sphereVBO, sphereEBO;
    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1, &sphereVBO);
    glGenBuffers(1, &sphereEBO);

    glBindVertexArray(sphereVAO);

    // Upload sphere vertex data to GPU
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sphereVertices.size() * sizeof(float), &sphereVertices[0], GL_STATIC_DRAW);

    // Upload sphere index data to GPU
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sphereIndices.size() * sizeof(unsigned int), &sphereIndices[0], GL_STATIC_DRAW);

    // Vertex attributes layout:
    // Location 0: position (vec3)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    // Location 1: normal (vec3)
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Location 2: texture coordinates (vec2)
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);


    // ---------------- Create and upload floor (plane) geometry ----------------
// Each vertex contains: position (vec3), normal (vec3), texture coordinates (vec2)
    float planeVertices[] = {
        // positions          // normals         // texcoords
        10.0f, 0.0f, 10.0f,     0, 1, 0,        10.0f, 0.0f,
        -10.0f, 0.0f, 10.0f,    0, 1, 0,        0.0f, 0.0f,
        -10.0f, 0.0f, -10.0f,   0, 1, 0,        0.0f, 10.0f,

        10.0f, 0.0f, 10.0f,     0, 1, 0,        10.0f, 0.0f,
        -10.0f, 0.0f, -10.0f,   0, 1, 0,        0.0f, 10.0f,
        10.0f, 0.0f, -10.0f,    0, 1, 0,        10.0f, 10.0f
    };

    unsigned int planeVAO, planeVBO;
    glGenVertexArrays(1, &planeVAO);
    glGenBuffers(1, &planeVBO);

    glBindVertexArray(planeVAO);

    // Upload vertex data for the floor plane
    glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW);

    // Vertex attribute layout:
    // Location 0: position (vec3)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    // Location 1: normal (vec3)
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Location 2: texture coordinates (vec2)
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void *)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    // ---------------- Load textures ----------------
    unsigned int basketballTex = loadTexture("basketball.jpg");
    unsigned int floorTex = loadTexture("floor.jpg");

    // ---------------- Main render loop ----------------
    while (!glfwWindowShouldClose(window))
    {
        // Time tracking for smooth motion
        float currentFrame = (float)glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // Handle keyboard input
        processInput(window);

        // Left mouse click triggers bounce if ball is idle
        if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS)
        {
            if (!isBouncing)
            {
                ballVelocityY = 8.0f; // Initial vertical velocity
                isBouncing = true;
            }
        }

        // Clear screen with sky-blue color and enable depth buffer
        glClearColor(0.4f, 0.7f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // ---------------- Render floor with lighting ----------------
        glUseProgram(shaderProgram);
        glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / SCR_HEIGHT, 0.1f, 100.0f);
        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniform3fv(glGetUniformLocation(shaderProgram, "viewPos"), 1, glm::value_ptr(cameraPos));
        glUniform1f(glGetUniformLocation(shaderProgram, "shininess"), 32.0f);

        // Set positions and properties for 2 dynamic point lights
        for (int i = 0; i < 2; i++)
        {
            float angle = (float)glfwGetTime() * (i % 2 == 0 ? 0.5f : -0.8f);
            glm::vec3 lightPos = glm::vec3(4.0f * cos(angle + i), 2.0f, 4.0f * sin(angle + i));
            std::string base = "pointLights[" + std::to_string(i) + "]";
            glUniform3fv(glGetUniformLocation(shaderProgram, (base + ".position").c_str()), 1, glm::value_ptr(lightPos));
            glUniform3f(glGetUniformLocation(shaderProgram, (base + ".ambient").c_str()), 0.05f, 0.05f, 0.05f);
            glUniform3f(glGetUniformLocation(shaderProgram, (base + ".diffuse").c_str()), 0.8f, 0.8f, 0.8f);
            glUniform3f(glGetUniformLocation(shaderProgram, (base + ".specular").c_str()), 1.0f, 1.0f, 1.0f);
        }

        // Draw floor with texture
        glBindVertexArray(planeVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, floorTex);
        glUniform1i(glGetUniformLocation(shaderProgram, "texture_diffuse1"), 0);
        glm::mat4 model = glm::mat4(1.0f);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Render ball's shadow using the shadow shader
        glUseProgram(shadowShaderProgram);
        // Bind the sphere VAO to render the shadow shape
        glBindVertexArray(sphereVAO);
        // Build the model matrix for the shadow object
        glm::mat4 shadowModel = glm::mat4(1.0f);

        /*
        // Dynamic shadow
        shadowModel = glm::translate(shadowModel, glm::vec3(0.0f, 0.01f, 0.0f)); // Slightly raise the shadow
        shadowModel = glm::scale(shadowModel, glm::vec3(1.0f, 0.05f, 1.0f));     // Flatten the shadow to simulate perspective
        */

        // Dynamic shadow scaling based on ball height
        float shadowScale = 1.0f - 0.5f * glm::clamp(ballPosY / 3.0f, 0.0f, 1.0f); // Higher ball, smaller shadow

        shadowModel = glm::mat4(1.0f);
        shadowModel = glm::translate(shadowModel, glm::vec3(0.0f, 0.01f, 0.0f)); // Slightly raise the shadow
        shadowModel = glm::scale(shadowModel, glm::vec3(shadowScale, 0.05f, shadowScale));

        glUniformMatrix4fv(glGetUniformLocation(shadowShaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(shadowModel));
        glUniformMatrix4fv(glGetUniformLocation(shadowShaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(shadowShaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_DEPTH_TEST);
        glDrawElements(GL_TRIANGLE_STRIP, (GLsizei)sphereIndices.size(), GL_UNSIGNED_INT, 0);
        glEnable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        glUseProgram(shaderProgram);

        // Set up basketball texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, basketballTex);
        glUniform1i(glGetUniformLocation(shaderProgram, "texture_diffuse1"), 0);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0f, 1.0f, 0.0f));
        //---------------------------------------------------------------------------------------  Bounce height calculation
        //        float bounceHeight = abs(sin(currentFrame * 3.0f)) * 1.0f + 0.5f;  // Value in [0.5, 1.0] range for bouncing effect
        /*
                const float ballRadius = 0.5f;
                float bounceHeight =  ballRadius * abs(sin(currentFrame * 3.0f));       // Calculate bounce height
                model = glm::translate(model, glm::vec3(0.0f, bounceHeight, 0.0f));
        */

        // ---------------- Render basketball model ----------------

        float bounceHeight = ballRadius * abs(sin(currentFrame * 3.0f));

        if (isBouncing)
        {
            ballVelocityY += gravity * deltaTime; // Update vertical velocity
            ballPosY += ballVelocityY * deltaTime;

            // Check for collision with the ground
            if (ballPosY <= 0.0f)
            {
                ballPosY = 0.0f;
                ballVelocityY = -ballVelocityY * damping; // Reverse velocity and apply damping

                // Stop bouncing if velocity is low enough
                if (abs(ballVelocityY) < 0.1f)
                {
                    ballVelocityY = 0.0f;
                    isBouncing = false;
                }
            }
        }
        model = glm::translate(model, glm::vec3(0.0f, ballPosY, 0.0f));
        // model = glm::translate(model, glm::vec3(0.0f, bounceHeight, 0.0f));

        //---------------------------------------------------------------------------------------
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
        glDrawElements(GL_TRIANGLE_STRIP, (GLsizei)sphereIndices.size(), GL_UNSIGNED_INT, 0);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Delete VBOs ---------------------------------------
    glDeleteVertexArrays(1, &sphereVAO);
    glDeleteBuffers(1, &sphereVBO);
    glDeleteBuffers(1, &sphereEBO);
    glDeleteVertexArrays(1, &planeVAO);
    glDeleteBuffers(1, &planeVBO);
    glfwTerminate();
    return 0;
}

// -------- Process input --------

void processInput(GLFWwindow *window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) // Close
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = 1.0f * deltaTime;

    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) // Sprint
        cameraSpeed *= 4.0f;
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS) // Jump
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS) // Crouch
        cameraPos += cameraSpeed * cameraUp;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) // Forward
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) // Backward
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) // Left
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) // Right
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
}

void framebuffer_size_callback(GLFWwindow *window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Mouse callback function
void mouse_callback(GLFWwindow *window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = (float)xpos;
        lastY = (float)ypos;
        firstMouse = false;
    }
    float xoffset = (float)xpos - lastX;
    float yoffset = lastY - (float)ypos;
    lastX = (float)xpos;
    lastY = (float)ypos;

    // Mouse sensitivity
    float sensitivity = 0.01f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;
    yaw += xoffset;
    pitch += yoffset;
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

void scroll_callback(GLFWwindow *window, double xoffset, double yoffset)
{
    fov -= (float)yoffset;
    if (fov < 1.0f)
        fov = 1.0f;
    if (fov > 45.0f)
        fov = 45.0f;
}

// Loads an image using stb_image and creates a 2D OpenGL texture with mipmaps
unsigned int loadTexture(const char *path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);
    int width, height, nrComponents;
    stbi_set_flip_vertically_on_load(true);
    unsigned char *data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format = (nrComponents == 1 ? GL_RED : (nrComponents == 3 ? GL_RGB : GL_RGBA));
        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        stbi_image_free(data);
    }
    else
    {
        std::cerr << "Texture fail: " << path << "\n";
        stbi_image_free(data);
    }
    return textureID;
}

void createSphere(std::vector<float> &vertices, std::vector<unsigned int> &indices,
                  unsigned int X_SEGMENTS, unsigned int Y_SEGMENTS)
{
    for (unsigned int y = 0; y <= Y_SEGMENTS; ++y)
    {
        for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
        {
            float xSegment = (float)x / (float)X_SEGMENTS;
            float ySegment = (float)y / (float)Y_SEGMENTS;
            float xPos = std::cos(xSegment * 2.0f * M_PI) * std::sin(ySegment * M_PI);
            float yPos = std::cos(ySegment * M_PI);
            float zPos = std::sin(xSegment * 2.0f * M_PI) * std::sin(ySegment * M_PI);

            vertices.push_back(xPos);
            vertices.push_back(yPos);
            vertices.push_back(zPos);
            // Normal
            vertices.push_back(xPos);
            vertices.push_back(yPos);
            vertices.push_back(zPos);
            // Texture coordinates
            vertices.push_back(xSegment);
            vertices.push_back(ySegment);
        }
    }
    bool oddRow = false;
    for (unsigned int y = 0; y < Y_SEGMENTS; ++y)
    {
        if (!oddRow)
        {
            for (unsigned int x = 0; x <= X_SEGMENTS; ++x)
            {
                indices.push_back(y * (X_SEGMENTS + 1) + x);
                indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
            }
        }
        else
        {
            for (int x = X_SEGMENTS; x >= 0; --x)
            {
                indices.push_back((y + 1) * (X_SEGMENTS + 1) + x);
                indices.push_back(y * (X_SEGMENTS + 1) + x);
            }
        }
        oddRow = !oddRow;
    }
}